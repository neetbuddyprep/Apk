package app.regainlite

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    private var lastBlocked = ""
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val p = getSharedPreferences("rules", MODE_PRIVATE)
        val until = p.getLong("focus_until", 0L)
        if (until < System.currentTimeMillis()) return
        val packageName = event.packageName?.toString() ?: return
        val blockedApps = p.getString("apps","")!!.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val appMatch = blockedApps.any { packageName == it }
        val texts = mutableListOf<String>()
        event.text?.forEach { texts.add(it.toString()) }
        rootInActiveWindow?.let { node ->
            fun collect(n: android.view.accessibility.AccessibilityNodeInfo?) {
                if (n == null) return
                n.text?.toString()?.let { texts.add(it) }
                n.contentDescription?.toString()?.let { texts.add(it) }
                for (i in 0 until n.childCount) collect(n.getChild(i))
            }
            collect(node)
        }
        val siteRules = p.getString("sites","")!!.lines().map { it.trim().lowercase() }.filter { it.isNotBlank() }
        val siteMatch = texts.any { t -> siteRules.any { rule -> t.lowercase().contains(rule) } }
        if ((appMatch || siteMatch) && lastBlocked != packageName) {
            lastBlocked = packageName
            val i = Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            i.putExtra("reason", if (siteMatch) "Website is on your block list" else "App blocked during focus")
            startActivity(i)
        }
        if (!appMatch && !siteMatch) lastBlocked = ""
    }
    override fun onInterrupt() {}
}
