package app.regainlite

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(32,32,32,32) }
        layout.addView(TextView(this).apply { text="PAUSE."; textSize=34f; gravity=Gravity.CENTER })
        layout.addView(TextView(this).apply { text=intent.getStringExtra("reason") ?: "Stay focused"; textSize=18f; gravity=Gravity.CENTER })
        layout.addView(Button(this).apply { text="Back to focus"; setOnClickListener { finish() } })
        setContentView(layout)
    }
    override fun onBackPressed() { finish() }
}
