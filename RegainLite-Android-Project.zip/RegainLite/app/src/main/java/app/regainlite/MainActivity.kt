package app.regainlite

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("rules", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        root.addView(TextView(this).apply { text="REGAIN LITE"; textSize=26f })
        root.addView(TextView(this).apply { text="Offline focus controls · rules stored on this device"; textSize=14f })
        val appInput = EditText(this).apply { hint="Blocked app package (e.g. com.instagram.android)"; setText(prefs.getString("apps","com.instagram.android,com.google.android.youtube")) }
        root.addView(appInput)
        val urlInput = EditText(this).apply { hint="Website URL / host to block (e.g. example.com)"; inputType=InputType.TYPE_TEXT_VARIATION_URI }
        root.addView(urlInput)
        root.addView(Button(this).apply { text="Save app & website rules"; setOnClickListener {
            prefs.edit().putString("apps",appInput.text.toString()).putString("sites", (prefs.getString("sites","")+"
"+urlInput.text.toString()).trim()).apply()
            Toast.makeText(this@MainActivity,"Rules saved locally",Toast.LENGTH_SHORT).show()
        }})
        root.addView(Button(this).apply { text="Enable accessibility blocker"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text="Start 25-minute focus"; setOnClickListener { prefs.edit().putLong("focus_until",System.currentTimeMillis()+25*60*1000).apply(); Toast.makeText(this@MainActivity,"Focus session started",Toast.LENGTH_SHORT).show() } })
        root.addView(Button(this).apply { text="Stop focus"; setOnClickListener { prefs.edit().remove("focus_until").apply() } })
        root.addView(TextView(this).apply { text="Note: Android accessibility matching is best-effort; app UI changes can affect detection. Website blocking depends on visible browser URL text, not encrypted network filtering."; textSize=13f })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
