# Regain Lite — native Android starter

Offline-first Kotlin project for a small trusted-group focus blocker. Rules are saved locally.

## What this starter includes
- Accessibility-service app detection during a local 25-minute focus session.
- Editable package-name block list (initial defaults include YouTube and Instagram).
- User-entered URL/host list with best-effort matching against visible accessibility text.
- Local block screen and manual focus stop/start.

## Important limitations
This is a **starter implementation, not a finished ReGain clone or a ready-tested APK**. YouTube Shorts / Instagram Reels are in-app surfaces, not separate Android packages. This first pass detects the containing app during focus; it does not yet reliably distinguish Shorts/Reels from ordinary content.
URL matching through accessibility is browser/UI-dependent and cannot inspect every HTTPS request. A robust URL blocker needs a local `VpnService` or browser-specific integration; DNS filtering alone cannot block individual URL paths. Strict mode, usage stats, app onboarding and battery/restart behavior still need testing and hardening.
Accessibility permission is powerful. Users should enable it only after reviewing the behavior.

## Build APK
Open this project in Android Studio (or compatible Android IDE) and build `app` → `assembleDebug`.
The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

GitHub Actions workflow is provided to build the APK remotely.
